/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import database.GarotaDAO;
import java.sql.SQLException;
import java.util.List;
import javax.inject.Inject;
import model.Garota;

/**
 *
 * @author iapereira
 */
@Controller
public class GarotaController {
    
    @Inject
    private Result result;
    
  
    @Path("/garota/listar")
    public void listar() throws SQLException, ClassNotFoundException{
        //return new GarotaDAO().listar();
        result.include("garotaList", new GarotaDAO().listar());
        result.include("nome", "Nossas Garotas...");
    }
    

//    @Path("/garota/listar")
//    public Tudao listar() throws SQLException, ClassNotFoundException{
//        //return new GarotaDAO().listar();
//        Tudao tudao = new Tudao();
//        tudao.setGarotaList(new GarotaDAO().listar());
//        tudao.setNome("Igor");
//        //result.include("garotaList", new GarotaDAO().listar());
//        //result.include("nome", "Igor");
//        return tudao;
//    }
//    
    
    
//    @Path("/garota/listar")
//    public List<Garota> listar() throws SQLException, ClassNotFoundException{
//        return new GarotaDAO().listar();
//    }
    
    
    @Path("/garota/tela_alterar/{id}")
    public Garota tela_alterar(int id) throws SQLException, ClassNotFoundException{
        return new GarotaDAO().obter(id);
    }
    
    
    @Path("/garota/excluir/{id}")
    public void excluir(int id) throws SQLException, ClassNotFoundException{
        new GarotaDAO().excluir(id);
        result.redirectTo(GarotaController.class).listar();
    }
    
    @Path("/garota/tela_adicionar")
    public void tela_adicionar(){
        
    }
    
    
    @Path("/garota/adicionar")
    @Post
    public void adicionar(Garota garota) throws SQLException, ClassNotFoundException{
        new GarotaDAO().adicionar(garota);
        result.redirectTo(GarotaController.class).listar();        
    }
    
    
    @Path("/garota/alterar")
    @Post
    public void alterar(Garota garota) throws SQLException, ClassNotFoundException{
        new GarotaDAO().alterar(garota);
        result.redirectTo(GarotaController.class).listar();        
    }
}
