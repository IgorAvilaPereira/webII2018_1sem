/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Result;
import static br.com.caelum.vraptor.view.Results.json;
import java.util.ArrayList;
import javax.inject.Inject;
import modelo.Aluno;

/**
 *
 * @author iapereira
 */
@Controller
public class AlunoController {

    @Inject
    private Result result;

    @Path("/aluno/listar")
    public void listar() {
        Aluno gustavo = new Aluno(11230193, "Gustavo");
        Aluno israel = new Aluno(11230188, "Israel");
        Aluno fernando = new Aluno(11230153, "Fernando");

        ArrayList<Aluno> vetAluno = new ArrayList();
        vetAluno.add(israel);
        vetAluno.add(gustavo);
        vetAluno.add(fernando);
        this.result.include("vetAluno", vetAluno);

    }

    @Get
    @Path("/aluno/ajax_busca/{parametro}")
    public void ajax_busca(String parametro) {

        Aluno gustavo = new Aluno(11230193, "Gustavo");
        Aluno israel = new Aluno(11230188, "Israel");
        Aluno fernando = new Aluno(11230153, "Fernando");

        ArrayList<Aluno> vetAluno = new ArrayList();
        vetAluno.add(israel);
        vetAluno.add(gustavo);
        vetAluno.add(fernando);

//        result.use(json()).from(gustavo).serialize();
        try {
            for (int i = 0; i < vetAluno.size(); i++) {
                Aluno aluno = vetAluno.get(i);
                if (aluno.getMatricula() == Integer.parseInt(parametro.trim())) {
                    result.use(json()).from(aluno).serialize();
                }
            }

        } catch (Exception e) {
            result.use(json()).from(new Aluno()).serialize();      
        }
    }

}
