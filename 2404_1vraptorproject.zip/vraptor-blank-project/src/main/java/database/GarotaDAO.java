/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Garota;

/**
 *
 * @author iapereira
 */
public class GarotaDAO {

    public List<Garota> listar() throws SQLException, ClassNotFoundException {
        Connection connection = new ConexaoPostgreSQL().getConnection();
        String sql = "select * from garota";
        PreparedStatement statement = connection.prepareStatement(sql);
        List<Garota> vetGarota = new ArrayList();
        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            Garota e = new Garota();
            e.setId(rs.getInt("id"));
            e.setNome(rs.getString("nome"));
            e.setHabilidades(rs.getString("habilidades"));
            vetGarota.add(e);
        }
        statement.close();
        connection.close();
        return vetGarota;
    }

    public void excluir(int id) throws SQLException, ClassNotFoundException {
        try (Connection connection = new ConexaoPostgreSQL().getConnection()) {
            String sql = "delete from garota where id = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            statement.executeUpdate();
            statement.close();
        }
    }

    public void adicionar(Garota garota) throws SQLException, ClassNotFoundException {

        try (Connection connection = new ConexaoPostgreSQL().getConnection()) {
            String sql = "insert into garota (nome, habilidades) values (?,?);";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, garota.getNome());
                statement.setString(2, garota.getHabilidades());
                statement.executeUpdate();
            }
        }
    }

    public Garota obter(int id) throws SQLException, ClassNotFoundException {

        Garota e;
        try (Connection connection = new ConexaoPostgreSQL().getConnection()) {
            String sql = "select * from garota where id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, id);
                ResultSet rs = statement.executeQuery();
                e = new Garota();
                if (rs.next()) {
                    e.setId(rs.getInt("id"));
                    e.setNome(rs.getString("nome"));
                    e.setHabilidades(rs.getString("habilidades"));
                }
            }
        }
        return e;
    }

    public void alterar(Garota garota) throws SQLException, ClassNotFoundException {
        try (Connection connection = new ConexaoPostgreSQL().getConnection()) {
            String sql = "update garota set nome = ?,  habilidades = ? where id = ?;";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, garota.getNome());
                statement.setString(2, garota.getHabilidades());
                statement.setInt(3, garota.getId());
                statement.executeUpdate();
            }
        }
    }
}
