/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.List;
import model.Garota;

/**
 *
 * @author iapereira
 */
public class Tudao {
    private List<Garota> garotaList;
    private String nome;

    public Tudao() {
        this.garotaList =  new ArrayList();
        
    }

    public List<Garota> getGarotaList() {
        return garotaList;
    }

    public void setGarotaList(List<Garota> garotaList) {
        this.garotaList = garotaList;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
    
    
}
